#ifndef FMT_MERGE_MSG_H
#define FMT_MERGE_MSG_H

extern int merge_log_config;
extern int fmt_merge_msg_config(const char *key, const char *value, void *cb);

#endif /* FMT_MERGE_MSG_H */
